

public class Capsula extends Nodriza{
    private boolean isVivo;
    
    public Capsula(){
        isVivo = true;
    }
    
    private String autoDestruccion(){
        String razon = "";
        
        if(!isViva){
            isVivo = false;
            
            razon = "Nodriza Destruida!!!";
        }
        
        return razon;
    }
}
