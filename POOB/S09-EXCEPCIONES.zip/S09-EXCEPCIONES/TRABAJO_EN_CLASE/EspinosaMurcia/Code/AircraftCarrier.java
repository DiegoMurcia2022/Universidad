 import java.util.List;

public class AircraftCarrier extends Ship {

	private int capacity;

	private List<Airplane> airplanes;

}
