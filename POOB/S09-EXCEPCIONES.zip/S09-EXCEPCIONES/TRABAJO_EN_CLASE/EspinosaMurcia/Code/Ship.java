import java.util.List;

public class Ship extends Nodriza{

	private int number;

	private List<Marine> marines;

}
