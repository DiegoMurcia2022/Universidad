import java.util.List;

public class Board {
    private List<Fleet> fleets;
    
    public int alNorte() throws BatallaNavalException{
        int cont = 0;
        
        for(Fleet i:fleets){
            i.alNorte();
            
            cont ++;
        }
        
        return cont;
    }
}
