import java.util.List;

public class Fleet {
    private String name;
    private Board board;
    private List<Machine> machines;
    private List<Marine> marines;

    public void alNorte() throws BatallaNavalException{
        int latitud = 20;
        
        for(Machine i:machines){
            i.moverMaquina(latitud,0);
        }
    }
}
