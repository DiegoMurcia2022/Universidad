public class BatallaNavalException extends Exception{
    public static final String OUT_OF_RANGE = "No se puede mover al norte";
    
    public BatallaNavalException(String message){
        super(message);
    }
}
