 public class Airplane extends Machine {

	private String licensePlate;

	private boolean isOnAir;

	private Marine copilot;

	private Marine pilot;

}
