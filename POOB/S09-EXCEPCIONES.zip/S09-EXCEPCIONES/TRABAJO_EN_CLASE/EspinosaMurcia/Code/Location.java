public class Location {
    private int latitude;
    private int longitude;
    
    public void changeLocation(int newLatitude,int newLongitude) throws BatallaNavalException{
        if((newLatitude<-100 && newLatitude>100)||(newLongitude<-100 && newLongitude>100)){
            throw new BatallaNavalException(BatallaNavalException.OUT_OF_RANGE);
        }
        else{
            latitude = newLatitude;
            longitude = newLongitude;
        }
    }
    
    public int getLatitude(){
        return latitude;
    }
    
    public int getLongitude(){
        return longitude;
    }
}
