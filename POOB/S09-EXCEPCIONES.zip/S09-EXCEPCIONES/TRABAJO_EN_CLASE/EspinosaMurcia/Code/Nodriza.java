import java.util.List;

public class Nodriza extends Machine{
    private List<Machine> capsulas;
    protected boolean isViva;

    public Nodriza(){
        isViva = true;
    }
}
