public abstract class Machine {
    private Location location;

    public void moverMaquina(int latitude,int longitude) throws BatallaNavalException{
        int x = location.getLatitude();
        int y = location.getLongitude();
        
        location.changeLocation(latitude+x,longitude+y);
    }
}
