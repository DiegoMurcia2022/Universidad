/*Prueba Trigger Clase T1_TriggerClase*/
INSERT INTO clase VALUES (16,'Clase5',15,25,'LO');
/*Prueba Trigger Horario T1_TriggerHorario*/
INSERT INTO horario VALUES (20,TO_DATE('04-10-2019','DD-MM-YYYY'),TO_TIMESTAMP('06:00','HH24:MI'),TO_TIMESTAMP('06:15','HH24:MI'));
/*Prueba Trigger Entrenador T1_TriggerEntrenador*/
INSERT INTO entrenador VALUES ('LevantamientoOlimpico',1234567891,12);
/*Prueba Trigger Apoyo T1_TriggerApoyo*/
INSERT INTO Apoyo VALUES ('Limpiesa',1234567891,97);
/*Prueba Trigger Clase T2_Trigger*/
INSERT INTO clase VALUES (7,'Clase5',15,55,'LO');
/*Prueba Trigger Horario T3_Trigger*/
INSERT INTO horario VALUES (7,TO_DATE('04-10-2019','DD-MM-YYYY'),TO_TIMESTAMP('06:00','HH24:MI'),TO_TIMESTAMP('06:15','HH24:MI'));
/*Prueba T4_Trigger*/
UPDATE usuario SET tipoUs='EX' WHERE nombre='Santiago';
/*Prueba T5*_Trigger*/
UPDATE Suscripcion SET numTitular=7777777777 WHERE numTitular=3132333435;
/*Prueba T6_Trigger*/
UPDATE Entrenador SET idPersonal=2222222222 WHERE idPersonal=1234567891;
