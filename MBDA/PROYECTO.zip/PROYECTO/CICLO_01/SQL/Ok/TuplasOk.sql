-----Clases-----
INSERT INTO clase VALUES (1,'Clase1',15,15,'LO');
INSERT INTO clase VALUES (2,'Clase2',30,20,'CM');
INSERT INTO clase VALUES (3,'Clase3',20,10,'CY');
INSERT INTO clase VALUES (4,'Clase4',15,15,'CG');
INSERT INTO clase VALUES (5,'Clase5',15,25,'LO');

-----Usuarios-----
INSERT INTO usuario VALUES (3132333435,'CC','Santiago','PE','santiago@hotmail.com','kr111',1);
INSERT INTO usuario VALUES (3637383940,'TI','Nikolas','PO','nikolas@hotmail.com','calle205',2);
INSERT INTO usuario VALUES (4142434445,'EX','Diego','PI','diego@hotmail.com','calle11kr50',3);
INSERT INTO usuario VALUES (4647484950,'CC','Angie','EG','angie@hotmail.com','calle100kr2',4);
INSERT INTO usuario VALUES (5152535455,'CC','Laura','PE','laura@hotmail.com','la7calle100',5);

-----Suscripciones-----
INSERT INTO suscripcion VALUES (3132333435,'CC','PE','Pago','24',250000,'todo');
INSERT INTO suscripcion VALUES (3637383940,'TI','PO','NoPago','12',200000,'todo');
INSERT INTO suscripcion VALUES (4142434445,'EX','PI','Cancelado','3',100000,'basico');
INSERT INTO suscripcion VALUES (4647484950,'CC','EG','Pago','12',300000,'todo');
INSERT INTO suscripcion VALUES (5152535455,'CC','PE','Cancelado','24',250000,'todo');
