/*Creacion del cuerpo del PAQUETE DE USUARIO*/
CREATE OR REPLACE PACKAGE BODY PA_USUARIO IS
    PROCEDURE AD_USUARIO(xidUs IN NUMBER,xtipoUs IN VARCHAR2,xnombre IN VARCHAR2,xtsub IN VARCHAR,xcorreo IN VARCHAR2,xdireccion IN VARCHAR2,xclase IN NUMBER)
    IS
    BEGIN
        INSERT INTO USUARIO VALUES(xidUs,xtipoUs,xnombre,xtsub,xcorreo,xdireccion,xclase);
        COMMIT;
        EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001,'No se realizo la operacion');
    END;

    PROCEDURE MO_USUARIO(xidUs IN NUMBER,xtsub IN VARCHAR, xcorreo IN VARCHAR2, xdireccion IN VARCHAR2)
    IS
    BEGIN
        UPDATE USUARIO SET tsub=xtsub,correo=xcorreo,direccion=xdireccion WHERE idUs=xidUs;
        COMMIT;
        EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001,'No se puede realizar la operacion');
    END MO_USUARIO;

    PROCEDURE EL_USUARIO(xidUs IN NUMBER) IS
    BEGIN
        DELETE FROM USUARIO WHERE idUs=xidUs;
        COMMIT;
        EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001,'No se pudo realizar la operacion');
    END EL_USUARIO;

    FUNCTION CO_USUARIO RETURN SYS_REFCURSOR IS INTERPRETE SYS_REFCURSOR;
    BEGIN
        OPEN INTERPRETE FOR
            SELECT * FROM USUARIO;
        RETURN INTERPRETE;
    END CO_USUARIO;

    FUNCTION CO_ESTADOINSCRIPCION RETURN SYS_REFCURSOR IS INTERPRETE SYS_REFCURSOR;
    BEGIN
        OPEN INTERPRETE FOR
            SELECT idUs,tsub FROM USUARIO;
        RETURN INTERPRETE;
    END CO_ESTADOINSCRIPCION;

    FUNCTION CO_ESTASUS(xnumTitular NUMBER) RETURN SYS_REFCURSOR IS INTERPRETE SYS_REFCURSOR;
    BEGIN
        OPEN INTERPRETE FOR
            SELECT numTitular, pay FROM SUSCRIPCION WHERE numTitular=xnumTitular;
        RETURN INTERPRETE;
    END CO_ESTASUS;

    FUNCTION CO_HOCLASE(xfecha DATE) RETURN SYS_REFCURSOR IS INTERPRETE SYS_REFCURSOR;
    BEGIN
        OPEN INTERPRETE FOR
            SELECT horaInicio FROM HORARIO WHERE fecha=SYSDATE;
        RETURN INTERPRETE;
    END CO_HOCLASE;

    FUNCTION CO_PER RETURN SYS_REFCURSOR IS INTERPRETE SYS_REFCURSOR;
    BEGIN
        OPEN INTERPRETE FOR
            SELECT * FROM PERSONAL;
        RETURN INTERPRETE;
    END CO_PER;

    FUNCTION CO_HOCLASE(xfecha DATE) RETURN SYS_REFCURSOR IS INTERPRETE SYS_REFCURSOR;
    BEGIN
        OPEN INTERPRETE FOR
            SELECT horaInicio FROM HORARIO WHERE fecha=SYSDATE;
        RETURN INTERPRETE;
    END CO_HOCLASE;

    PROCEDURE UP_PAY(XnumTitular IN NUMBER)
    IS
    BEGIN
        UPDATE SUSCRIPCION SET pay='Pago' WHERE numTitular=xnumTitular;
        COMMIT;
        EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001,'La operacion no se pudo ejecutar');
    END UP_PAY;
END PA_USUARIO;
-------------------------------------------------------------------------------------------------
/*Creacion del cuerpo del PAQUETE CLASE*/
CREATE OR REPLACE PACKAGE BODY PA_CLASE IS
    PROCEDURE AD_CLASE(xidCa IN NUMBER,xnombre IN VARCHAR2,xduracion IN NUMBER,xcupos IN NUMBER, xtipo IN CHAR)
    IS
    BEGIN
        INSERT INTO CLASE VALUES (xidCa,xnombre,xduracion,xcupos,xtipo);
        COMMIT;
        EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(20001,'La operacion no se pudo ejecutar');
    END AD_CLASE;

    PROCEDURE UP_CLASE(xidCa IN NUMBER,xtipo IN CHAR)
    IS
    BEGIN
        UPDATE CLASE SET tipo=xtipo WHERE idCa=xidCa;
        COMMIT;
        EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001,'La operacion no se pudo ejecutar');
    END UP_CLASE;

    PROCEDURE DE_CLASE(xidCa IN NUMBER)
    IS
    BEGIN
        DELETE FROM CLASE WHERE idCa=xidCa;
        COMMIT;
        EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001,'La operacion no se pudo ejecutar');
    END DE_CLASE;

    PROCEDURE AD_HORARIO(xidClase IN NUMBER,xfecha IN DATE,xhorarioInicio IN TIMESTAMP,xhorarioFinal IN TIMESTAMP,clase IN NUMBER)
    IS
    BEGIN
        INSERT INTO HORARIO VALUES(xidClase,xfecha,xhorarioInicio,xhorarioFinal,clase);
        COMMIT;
        EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(20001,'No se pudo ejecutar la operacion');
    END AD_HORARIO;

    PROCEDURE UP_HORARIO(xidClase IN NUMBER, xhorarioFinal IN TIMESTAMP)
    IS
    BEGIN
        UPDATE HORARIO SET horaFinal=xhorarioFinal WHERE idClase=xidClase;
        COMMIT;
        EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001,'La operacion no se pudo ejecutar');
    END UP_HORARIO;

    PROCEDURE DE_HORARIO(xidClase IN NUMBER)
    IS
    BEGIN
        DELETE FROM HORARIO WHERE idClase=xidClase;
        COMMIT;
        EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001,'La operacion no se pudo ejecutar');
    END DE_HORARIO;

    FUNCTION CO_HORARIO RETURN SYS_REFCURSOR IS INTERPRETE SYS_REFCURSOR;
    BEGIN
        OPEN INTERPRETE FOR
            SELECT idClase,horaInicio,clase FROM HORARIO;
        RETURN INTERPRETE;
    END CO_HORARIO;
END PA_CLASE;
/*Creacion del cuerpo del PAQUETE PERSONAL*/
CREATE OR REPLACE PACKAGE BODY PA_PERSONAL IS
    PROCEDURE AD_PERSONAL(xidPersonal IN NUMBER,xhorario IN VARCHAR2)
    IS
    BEGIN
        INSERT INTO PERSONAL VALUES(xidPersonal,xhorario);
        COMMIT;
        EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001,'La operacion no se pudo ejecutar');
    END AD_PERSONAL;

    PROCEDURE UP_PERSONAL(xidPersonal IN NUMBER, xhorario IN VARCHAR2)
    IS
    BEGIN 
        UPDATE PERSONAL SET horario=xhorario WHERE idPersonal=xidPersonal;
        COMMIT;
        EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001,'La operacion no se puede ejecutar');
    END UP_PERSONAL;

    PROCEDURE DE_PERSONAL(xidPersonal IN NUMBER)
    IS
    BEGIN
        DELETE FROM PERSONAL WHERE idPersonal=xidPersonal;
        COMMIT;
        EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001,'La operacion no se pudo ejecutar');
    END DE_PERSONAL;

    FUNCTION CO_PERSONAL RETURN SYS_REFCURSOR IS INTERPRETE SYS_REFCURSOR;
    BEGIN
        OPEN INTERPRETE FOR
            SELECT * FROM PERSONAL,ENTRENADOR,APOYO;
        RETURN INTERPRETE;
    END CO_PERSONAL;

    FUNCTION CO_ESPECIALIZACION RETURN SYS_REFCURSOR IS INTERPRETE SYS_REFCURSOR;
    BEGIN
        OPEN INTERPRETE FOR
            SELECT PERSONAL.idPersonal,especializacion FROM PERSONAL JOIN ENTRENADOR ON(PERSONAL.idPersonal=ENTRENADOR.idPersonal);
        RETURN INTERPRETE;
    END CO_ESPECIALIZACION;

    FUNCTION CO_TIPOTRABAJO RETURN SYS_REFCURSOR IS INTERPRETE SYS_REFCURSOR;
    BEGIN
        OPEN INTERPRETE FOR
            SELECT PERSONAL.idPersonal,TipoTraba FROM PERSONAL JOIN APOYO ON(PERSONAL.idPersonal=APOYO.idPersonal);
        RETURN INTERPRETE;
    END CO_TIPOTRABAJO;
END PA_PERSONAL;

