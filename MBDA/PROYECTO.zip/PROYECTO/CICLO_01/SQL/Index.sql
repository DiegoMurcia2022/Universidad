/*Indice para el atributo horaInicio*/
CREATE INDEX in_horarioInicio ON Horario (fecha,horaInicio);

/*Indice para el precio,pay en Suscripcion*/
CREATE INDEX in_precio ON Suscripcion (precio,pay);
