ALTER TABLE Horario ADD CONSTRAINT PK_idclase PRIMARY KEY(idClase);
ALTER TABLE Clase ADD CONSTRAINT PK_idCa PRIMARY KEY(idCa);
ALTER TABLE Usuario ADD CONSTRAINT PK_idus PRIMARY KEY(idUs);
ALTER TABLE Suscripcion ADD CONSTRAINT PK_idsub PRIMARY KEY(numSuscripcion);
ALTER TABLE PlanEspartanos ADD CONSTRAINT PK_esparnum PRIMARY KEY(numSuscripcion);
ALTER TABLE PlanOlimpico ADD CONSTRAINT PK_olimnum PRIMARY KEY(numSuscripcion);
ALTER TABLE PlanDeInicio ADD CONSTRAINT PK_inicionum PRIMARY KEY(numSuscripcion);
ALTER TABLE EliteGold ADD CONSTRAINT PK_elitenum PRIMARY KEY(numSuscripcion);
ALTER TABLE Entrenador ADD CONSTRAINT PK_entre PRIMARY KEY(idPersonal);
ALTER TABLE Apoyo ADD CONSTRAINT PK_apoyo PRIMARY KEY(idPersonal);
ALTER TABLE Personal ADD CONSTRAINT PK_pers PRIMARY KEY(idPersonal);
-----------------------------------------------------------------------
ALTER TABLE Horario ADD CONSTRAINT PF_idclase FOREIGN KEY (clase) REFERENCES Clase(idCa);
ALTER TABLE Entrenador ADD CONSTRAINT PF_entrenador FOREIGN KEY (idClase) REFERENCES Clase(idCa) ON DELETE SET NULL;
ALTER TABLE Apoyo ADD CONSTRAINT PF_apoyo FOREIGN KEY (idClase) REFERENCES Clase(idCa) ON DELETE SET NULL;
ALTER TABLE Apoyo ADD CONSTRAINT PF_id2 FOREIGN KEY (idPersonal) REFERENCES Personal(idPersonal);
ALTER TABLE Usuario ADD CONSTRAINT PF_usuario FOREIGN KEY (clase) REFERENCES Clase(idCa)ON DELETE SET NULL;
ALTER TABLE Suscripcion ADD CONSTRAINT PF_suscrip FOREIGN KEY (numTitular) REFERENCES Usuario(idUs);


ALTER TABLE PlanDeInicio ADD CONSTRAINT PF_inicionum FOREIGN KEY (numSuscripcion) REFERENCES Suscripcion(numSuscripcion);
ALTER TABLE EliteGold ADD CONSTRAINT PF_elitenum FOREIGN KEY (numSuscripcion) REFERENCES Suscripcion(numSuscripcion);
ALTER TABLE PlanEspartanos ADD CONSTRAINT PF_espartnum FOREIGN KEY (numSuscripcion) REFERENCES Suscripcion(numSuscripcion);
ALTER TABLE PlanOlimpico ADD CONSTRAINT PF_olimnum FOREIGN KEY (numSuscripcion) REFERENCES Suscripcion(numSuscripcion);
ALTER TABLE Entrenador ADD CONSTRAINT PF_id1 FOREIGN KEY (idPersonal) REFERENCES Personal(idPersonal);
