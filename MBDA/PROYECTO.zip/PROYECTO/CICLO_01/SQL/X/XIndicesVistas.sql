/*Eliminacion de Vistas*/
DROP VIEW Revisar_Pago;
DROP VIEW Consultar_Horario;
/*Eliminacion de Indices*/
DROP INDEX in_horarioInicio ON horario;
DROP INDEX in_precio ON Suscripcion; 