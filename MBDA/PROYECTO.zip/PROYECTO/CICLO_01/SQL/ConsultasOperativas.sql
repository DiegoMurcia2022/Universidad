/*Consultar el estado de la suscripcion*/
SELECT Usuario.numTitular, usuario.nombre, pay, idSub
FROM Suscripcion JOIN Usuario ON (Suscripcion.numTitular=Usuario.numTitular)
WHERE Usuario.numTitular=/*numero de identificacion*/
----------------------------------------------------------------------
/*Consultar horario de clases*/
SELECT nombre.Clase, Horario.fecha, Horario.horaInicio
FROM Clase JOIN Horaio ON (idCa=idClase)
WHERE Horario.fecha=SYSDATE
GROUP BY Clase.nombre