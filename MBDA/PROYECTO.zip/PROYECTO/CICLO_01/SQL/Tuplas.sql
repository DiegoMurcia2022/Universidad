ALTER TABLE Clase ADD CONSTRAINT CK_Clase CHECK((duracion BETWEEN 1 AND 60) AND (tipo IN ('LO','CM','CY','CG')));
ALTER TABLE Usuario ADD CONSTRAINT CK_Usuario CHECK((REGEXP_LIKE (correo, '^(\S+)\@(\S+)\.(\S+)$')) AND (tipoUs IN('CC','TI','EX')) AND (REGEXP_LIKE(direccion,'^[A-Z,0-9]*$')) AND (tsub IN('PE','PO','PI','EG')));
ALTER TABLE Suscripcion ADD CONSTRAINT Ck_Suscripcion CHECK((pay IN('Pago','NoPago','Cancelado')) AND (idSub IN('PE','PO','PI','EG')) AND (tipoTitular IN('CC','TI','EX')) AND (Complemento IN('todo','basico')) AND (precio BETWEEN 100000 AND 400000));
