INSERT INTO ProveedorMate VALUES ('BODYTECH','boy@tech.co','170NORTE','
<detalle>
    <NombreEmpresa> BODYTECH </NombreEmpresa>
    <AñosTrabajo AñosColombia = "20" AñosFuera = "0"> </AñosTrabajo>
    <Pais> Colombia </Pais>
    <NIT> 1000000001 </NIT>
    <NumeroCuenta> 1011121314 </NumeroCuenta>
</detalle>');

INSERT INTO Telefono(teleProve) VALUES (111213151617181920);

INSERT INTO MaterialClase VALUES (5,'Barra Roja','No Bien','Tener cuidado con el manejo');

INSERT INTO SuministradoPor VALUES (35,1);

