DROP TABLE SuministradoPor;
DROP TABLE Telefono;
DROP TABLE ProveedorMate;
DROP TABLE MaterialClase;