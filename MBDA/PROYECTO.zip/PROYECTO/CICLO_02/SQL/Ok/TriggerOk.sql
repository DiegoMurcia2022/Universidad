/*Trigger Consecurtivo Prove*/
INSERT INTO ProveedorMate(nombre,correo,direccion,detalle) VALUES ('BOXSANTI','santiBox@hotmail.com','85SUR','
<detalle>
    <NombreEmpresa> BOXSANTI </NombreEmpresa>
    <AñosTrabajo AñosColombia = "5" AñosFuera = "2"> </AñosTrabajo>
    <Pais> 1000000011 </NIT>
    <NumeroCuenta> 1111121315 </NumeroCuenta>
</detalle>');

/*Trigger ConsecutivoTelefono*/
INSERT INTO Telefono(TeleProve) VALUES (1234567890);

/*Consecutivo SuministradoP*/
INSERT INTO SuministradoPor(NombreProve,CantidadMaterial,idMaterial) VALUES ('BOXSANTI',5,3);

/*ConecutivoMaterialClase*/
INSERT INTO MaterialClase(caracteristicas,estado,recomendaciones) VALUES ('Barra','Nuevo','No dejar caer al suelo');

/*EliminarMaterial*/
DELETE FROM MaterialClase WHERE caracteristicas = 'Barra';
