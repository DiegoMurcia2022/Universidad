INSERT INTO ProveedorMate VALUES (1,'ROGUE','team@rogueeurope.eu','1420WALLSTREET','
<detalle>
    <NombreEmpresa> Rogue </NombreEmpresa>
    <AñosTrabajo AñosColombia="5" AñosFuera="10"> </AñosTrabajo>
    <Pais> United States </Pais>
    <NIT> 1111111111 </NIT>
    <NumeroCuenta> 1010101010 </NumeroCuenta>
</detalle>');
INSERT INTO ProveedorMate VALUES (10,'BODYTECH','boy@tech.co','170NORTE','
<detalle>
    <NombreEmpresa> BODYTECH </NombreEmpresa>
    <AñosTrabajo AñosColombia = "20" AñosFuera = "0"> </AñosTrabajo>
    <Pais> Colombia </Pais>
    <NIT> 1000000001 </NIT>
    <NumeroCuenta> 1011121314 </NumeroCuenta>
</detalle>');
INSERT INTO ProveedorMate(nombre,correo,direccion,detalle) VALUES ('BOXSANTI','santiBox@hotmail.com','85SUR','
<detalle>
    <NombreEmpresa> BOXSANTI </NombreEmpresa>
    <AñosTrabajo AñosColombia = "5" AñosFuera = "2"> </AñosTrabajo>
    <Pais> 1000000011 </NIT>
    <NumeroCuenta> 1111121315 </NumeroCuenta>
</detalle>');

INSERT INTO Telefono VALUES (1,1234567890);
INSERT INTO Telefono VALUES (2,11121315);
INSERT INTO Telefono VALUES (3,1889674521);

INSERT INTO MaterialClase VALUES (1,'Barra','Nuevo','No dejar caer al suelo');
INSERT INTO MaterialClase VALUES (5,'Mancuerna','Bien','Tener cuidado con el manejo');
INSERT INTO MaterialClase(caracteristicas,estado,recomendaciones) VALUES ('Estructura','Cambio','No usar hasta que se renueve');

INSERT INTO SuministradoPor VALUES (1,'ROGE',15,1);
INSERT INTO SuministradoPor VALUES (2,'BODYTECH',35,2);
INSERT INTO SuministradoPor VALUES (3,'BOXSANTI',5,3);
