CREATE OR REPLACE PACKAGE BODY PC_ADMINISTRADOR IS
    PROCEDURE AD_MATERIALad(xidMaterial IN NUMBER, xcaracteristicas IN VARCHAR2, xestado IN VARCHAR2, xrecomendaciones IN VARCHAR2) IS
    BEGIN
        INSERT INTO MaterialClase VALUES(xidMaterial,xcaracteristicas,xestado,xrecomendaciones);
    END AD_MATERIALad;

    PROCEDURE UP_MATERIALad(xidMaterial IN NUMBER,xestado IN VARCHAR2,xrecomendaciones IN VARCHAR2) IS
    BEGIN
        UPDATE MaterialClase SET estado=xestado,recomendaciones=xrecomendaciones WHERE idMaterial=xidMaterial;
    END UP_MATERIALad;

    PROCEDURE DE_MATERIALad(xidMaterial IN NUMBER) IS
    BEGIN
        DELETE FROM MaterialClase WHERE idMaterial=xidMaterial;
    END DE_MATERIALad;

    FUNCTION CO_MATERIALad(xidMaterial NUMBER) RETURN SYS_REFCURSOR IS SEÑOR SYS_REFCURSOR;
    BEGIN
        OPEN SEÑOR FOR
            SELECT idMaterial,estado FROM MaterialClase;
        RETURN SEÑOR;
    END CO_MATERIALad;

    PROCEDURE AD_PROVEEDORad(xidProveedor IN NUMBER, xnombre IN VARCHAR2, xcorreo IN VARCHAR2,xdireccion IN VARCHAR2,xdetalle IN XMLTYPE) IS
    BEGIN
        INSERT INTO ProveedorMate VALUES(xidProveedor,xnombre,xcorreo,xdireccion,xdetalle);
    END AD_PROVEEDORad;

    PROCEDURE AD_TELEFONOad(xidProveedor IN NUMBER,xTeleProve IN NUMBER) IS
    BEGIN
        INSERT INTO Telefono VALUES(xidProveedor,xTeleProve);
    END AD_TELEFONOad;

    PROCEDURE UP_PROVEEDORad(xidProveedor IN NUMBER, xDireccion IN VARCHAR2) IS
    BEGIN
        UPDATE  ProveedorMate SET Direccion=xDireccion WHERE idProveedor=xidProveedor;
    END UP_PROVEEDORad;

    PROCEDURE UP_TELEFONOad(xidProveedor IN NUMBER, xTeleProve IN NUMBER) IS
    BEGIN
        UPDATE Telefono SET TeleProve=xTeleProve WHERE idProveedor=xidProveedor;
    END UP_TELEFONOad;

    PROCEDURE DE_PROVEEDORad(xidProveedor IN NUMBER) IS
    BEGIN
        DELETE FROM ProveedorMate WHERE idProveedor=xidProveedor;
    END DE_PROVEEDORad;

    FUNCTION CO_PROVEEDORad(xidProveedor NUMBER) RETURN SYS_REFCURSOR IS SEÑOR SYS_REFCURSOR;
    BEGIN
        OPEN SEÑOR FOR
            SELECT * FROM ProveedorMate JOIN Telefono ON (ProveedorMate.idProveedor=Telefono.idProveedor);
        RETURN SEÑOR;
    END CO_PROVEEDORad;
END PC_ADMINISTRADOR;

CREATE OR REPLACE PACKAGE BODY PC_PROFESOR IS
    PROCEDURE UP_MATERIALpo(xidMaterial IN NUMBER,xestado IN VARCHAR2,xrecomendaciones IN VARCHAR2) IS
    BEGIN
        UPDATE MaterialClase SET estado=xestado,recomendaciones=xrecomendaciones WHERE idMaterial=xidMaterial;
    END UP_MATERIALpo;
END PC_PROFESOR;