/*Creacion Checks de los atributos del Ciclo Dos*/
ALTER TABLE ProveedorMate ADD CONSTRAINT CK_Correo CHECK(REGEXP_LIKE (Correo, '^(\S+)\@(\S+)\.(\S+)$'));
ALTER TABLE ProveedorMate ADD CONSTRAINT CK_Direccion CHECK(REGEXP_LIKE(Direccion,'^[A-Z,0-9]*$'));
ALTER TABLE MaterialClase ADD CONSTRAINT CK_Caracteristica CHECK(caracteristicas IN ('Barra','Balon','Lazo','Mancuerna','Pesa Rusa','Estructura'));
ALTER TABLE MaterialClase ADD CONSTRAINT CK_Estado CHECK(estado IN ('Nuevo','Bien','Medio','Cambio'));
