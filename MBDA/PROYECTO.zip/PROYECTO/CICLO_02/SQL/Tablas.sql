CREATE TABLE ProveedorMate(
    idProveedor NUMBER NOT NULL,
    Nombre VARCHAR2(50),
    Correo VARCHAR2(50),
    Direccion VARCHAR2(50),
    Detalle XMLTYPE NOT NULL
);

CREATE TABLE Telefono(
    idProveedor NUMBER,
    TeleProve NUMBER(10)
);

CREATE TABLE SuministradoPor(
    idProveedor NUMBER,
    NombreProve VARCHAR2(50),
    CantidadMaterial NUMBER,
    idMaterial NUMBER
);

CREATE TABLE MaterialClase(
    idMaterial NUMBER NOT NULL,
    caracteristicas VARCHAR2(50),
    estado VARCHAR2(50),
    recomendaciones VARCHAR2(50)
);
