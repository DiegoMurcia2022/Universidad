/*Creacion Views Ciclo Dos*/
CREATE VIEW Vi_estado AS (SELECT idMaterial,estado FROM MaterialClase);
CREATE VIEW Vi_proveedor AS (SELECT * FROM ProveedorMate);
