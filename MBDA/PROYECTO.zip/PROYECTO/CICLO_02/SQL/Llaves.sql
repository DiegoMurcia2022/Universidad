/*Creacion Llaves Primarias*/
ALTER TABLE ProveedorMate ADD CONSTRAINT PK_Proveedor PRIMARY KEY(idProveedor);
ALTER TABLE Telefono ADD CONSTRAINT PK_Telefono PRIMARY KEY(idProveedor,TeleProve);
ALTER TABLE SuministradoPor ADD CONSTRAINT PK_Suministrado PRIMARY KEY(idProveedor,idMaterial);
ALTER TABLE MaterialClase ADD CONSTRAINT PK_Material PRIMARY KEY(idMaterial);

/*Creacion Llaves Foraneas*/
ALTER TABLE Telefono ADD CONSTRAINT PF_Telefono FOREIGN KEY (idProveedor) REFERENCES ProveedorMate(idProveedor) ON DELETE SET NULL;
ALTER TABLE SuministradoPor ADD CONSTRAINT PF_Proveedor FOREIGN KEY (idProveedor) REFERENCES ProveedorMate(idProveedor);
ALTER TABLE SuministradoPor ADD CONSTRAINT PF_Material FOREIGN KEY (idMaterial) REFERENCES MaterialClase(idMaterial);

/*Creacion Llaves Unicas*/
ALTER TABLE MaterialClase ADD UNIQUE(recomendaciones);

