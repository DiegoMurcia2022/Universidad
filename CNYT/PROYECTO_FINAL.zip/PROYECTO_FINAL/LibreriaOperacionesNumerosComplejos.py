import math

def suma(a,b):
    """
    La funcion suma recibe 2 numeros complejos a y b que deben ser listas de longitud 2
    y retorna un complejo (lista de longitud 2) correspondiente a la operacion a+b.
    """
    
    return [a[0]+b[0],a[1]+b[1]]

def resta(a,b):
    """
    La funcion resta recibe 2 numeros complejos a y b que deben de ser listas de longitud 2
    y retorna un complejo (lista de longitud 2) correspondiente a la operacion a-b.
    """

    return [a[0]-b[0],a[1]-b[1]]

def multiplicacion(a,b):
    """
    La funcion multiplicacion recibe 2 numeros complejos a y b que deben de ser listas de
    longitud 2 y retorna un complejo (lista de longitud 2) correspondiente a la operacion
    a*b.
    """

    real = a[0]*b[0]+((a[1]*b[1])*-1)
    imaginario = a[0]*b[1]+a[1]*b[0]

    return [real,imaginario]

def conjugado(a):
    """
    La funcion conjugado recibe un numero complejo a que debe ser una lista de longitud 2 y
    retorna un complejo (lista de longitud 2) correspondiente a la operacion de hallar el
    conjugado del numero complejo a.
    """

    return [a[0],a[1]*(-1)]

def division(a,b):
    """
    La funcion division recibe 2 numeros complejos a y b que deben ser una lista de longitud 2
    y retorna un complejo (lista de longitud 2) correspondiente a la operacion a/b.
    """

    conju = conjugado(b)
    numerador = multiplicacion(a,conju)
    denominador = multiplicacion(b,conju)

    return [numerador[0]/denominador[0],numerador[1]/denominador[0]]

def modulo(a):
    """
    La funcion modulo recibe un numero complejo a que debe ser una lista de longitud 2 y
    retorna un numero complejo que corresponde a la operacion de hallar el modulo del numero
    complejo a.
    """

    operacion = (a[0]**2+a[1]**2)**(1/2)
    
    return operacion

def faseNumeroComplejo(a):
    """
    La funcion faseNumeroComplejo recibe un numero complejo a que debe ser una lista de
    longitud 2 y retorna la fase del numero complejo en radianes.
    """

    return math.atan2(a[1],a[0])

def conversionComplejoPolar(a):
    """
    La funcion conversionComplejoPolar recibe un numero complejo a que debe ser una lista de
    longitud 2 con su fase en radianes, y retorna una lista de longitud 2 que contiene las coordenadas polares del
    numero complejo.
    """

    mod = modulo(a)
    fase = faseNumeroComplejo(a)

    return [mod,fase]

def conversionPolarComplejo(a):
    """
    La funcion conversionPolarComplejo recibe una lista de longitud 2 que contiene las coordenadas
    polares de un numero complejo, y retorna un numero complejo (lista de longitud 2).    
    """

    real = a[0]*math.cos(a[1])
    imaginario = a[0]*math.sin(a[1])

    return [real,imaginario]

def mostrar(a):
    """
    La funcion mostrar recibe una lista de longitud dos que representan a un numero complejo y
    retorna la representaion matematica de un numero complejo.
    """

    cadena = str(a[0])+"+"+"("+str(a[1])+")"+"i"
    
    return cadena

def formaPolarExponencial(a):
    """
    La funcion formaPolarExponencia recibe una lista de longitud 2 que representa las coordenadas
    polares de un numero complejo, y retorna la representacion exponencial de estas coordenadas.
    """

    exponencial = str(a[0])+"e"+"^"+"i"+"("+str(a[1])+")"

    return exponencial

def potenciaN(a,b):
    """
    La funcion potencia N recibe una lista a de longitud 2 que representa un numero complejo y la potencia
    a la que se elevara, y retornara la operacion de a^b.
    """

    if b>1:
        rta = 0
        
        for i in range(1,b+1):
            if i==1:
                rta = a
            else:
                rta = multiplicacion(rta,a)

        return rta
    elif b==1:
        return a
