# Ciencias Naturales y Tecnología (CNYT) 
Proyecto Final de Curso <br />
Realizado por Diego Alejandro Murcia Céspedes <br />
13 de Mayo del 2020 <br />
<br />

## Contenido Proyecto Final de Curso 📖
Aqui podran encontrar un informe sobre el algoritmo de Deutsch-Jozsa en el cual se analizaron dos casos de
su algoritmo, pero ademas se realizo un circuito de dichos casos en el simulador cuantico de IBM para llegar a
unas conclusiones finales. <br />
<br />
Tambien encontrar otro Jupyter Notebook en el cual se realizan el modelado de la esfera de Bloch para diferentes
matrices de dinamica cuantica con dimension 2.

## Sintaxis 📜
Se recomienda leer la sintaxis de las librerias que se muestran a continuacion ya que para la seccion de la esfera de Bloch se utiliza (las librerias las puede encontrar en otro proyectos de este repositorio).

Lea atentamente la <a href="http://htmlpreview.github.com/?https://github.com/DiegoMurcia2022/Universidad/blob/master/CNYT/PROYECTO/html/LibreriaOperacionesNumerosComplejos.html">sintaxis</a> de las funciones ofrecidas por la libreria de operaciones basicas con numeros complejos para evitar errores durante su ejecucion. <br/>
<br/>
Tambien lea atentamete la <a href="http://htmlpreview.github.com/?https://github.com/DiegoMurcia2022/Universidad/blob/master/CNYT/PROYECTO/html/LibreriaOperacionesVectoresMatricesComplejos.html">sintaxis</a> de la libreria de funciones para vectores y matrices complejas para igualmente evitar errores de ejecucion durante el uso de estas funciones.

## Comentarios
Si se va a hacer uso de esta libreria cite en su codigo de la manera que se mostrara a continuacion: <br />

```python
"""
Libreria desarrollada por Diego Alejandro Murcia Céspedes
Tomado de repositorio https://github.com/DiegoMurcia2022/Universidad/tree/master/CNYT/PROYECTO 
en GitHub.
"""
```

En caso de hacer uso de alguno de los Jupyter Notebook en este repositorio por favor citar con el nombre del autor y link del repositorio.
