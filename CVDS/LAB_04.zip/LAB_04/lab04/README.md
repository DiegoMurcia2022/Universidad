# LABORATORIO No.04
Los integrantes de este laboratorio son:
* Nikolas Bernal Giraldo
* Diego Alejandro Murcia Cespedes

## Clases De Equivalencia
* **OriginalScore**

    Ingreso de los parametros:
    ```java
    correctCount<0 OR incorrectCount<0 //Lanzar Excepcion por parametros invalidos

    incorrectCount>10 //Retornar 0 porque no puede ser menos de 0 puntos
    ```

* **BonusScore**

    Ingreso de los parametros:
    ```java
    correctCount<0 OR incorrectCount < 0 //Lanzar Excepcion por parametros invalidos

    puntaje<0 //Retorna 0 porque no puede ser menos de 0 puntos
    ```

* **PowerScore**

    Ingreso de los parametros:
    ```java
    correctCount<0 OR incorrectCount<0 //Lanzar Excepcion por parametros invalidos

    puntaje<0 //Retorna 0 porque no puede ser menos de 0 puntos

    puntaje>500 //Retorna 500 porque no puede ser mayor de 500 puntos
    ```