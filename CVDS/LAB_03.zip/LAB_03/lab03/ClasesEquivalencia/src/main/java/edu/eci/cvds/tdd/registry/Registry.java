package edu.eci.cvds.tdd.registry;

import java.util.ArrayList;

public class Registry {
    private ArrayList<Integer> ids = new ArrayList<Integer>();

    public RegisterResult registerVoter(Person p){
        if(validatePerson(p)){
            ids.add(p.getId());

            return RegisterResult.VALID;
        }
        else{
            if(!p.isAlive()){
                return RegisterResult.DEAD;
            }
            else if(ids.contains(p.getId())){
                return RegisterResult.DUPLICATED;
            }
            else if(p.getAge()<18 && p.getAge()>0){
                return RegisterResult.UNDERAGE;
            }
            else{
                return RegisterResult.INVALID_AGE;
            }
        }
    }

    private boolean validatePerson(Person p){
        boolean valid = false;
        
        if(p.getAge()>=18 && p.getAge()<=120){
            if(p.isAlive()){
                if(!ids.contains(p.getId())){
                    valid = true;
                }
            }
        }

        return valid;
    }
}
