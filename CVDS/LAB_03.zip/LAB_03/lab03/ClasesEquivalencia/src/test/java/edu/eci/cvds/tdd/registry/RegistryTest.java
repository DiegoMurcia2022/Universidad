package edu.eci.cvds.tdd.registry;

import org.junit.Assert;
import org.junit.Test;

public class RegistryTest {
    private Registry registry = new Registry();

    @Test
    public void validateRegistryResultIsAlive() {
        Person person = new Person();

        RegisterResult result = registry.registerVoter(person);

        Assert.assertEquals(RegisterResult.DEAD, result);
    }

    @Test
    public void validateRegistryResultUnderAge() {
        Person person = new Person("DIEGO",2159096,17,Gender.MALE,true);

        RegisterResult result = registry.registerVoter(person);

        Assert.assertEquals(RegisterResult.UNDERAGE, result);
    }

    @Test
    public void validateRegistryResultInvalidAge(){
        Person person = new Person("NIKOLAS",2158547,-20,Gender.MALE,true);

        RegisterResult result = registry.registerVoter(person);

        Assert.assertEquals(RegisterResult.INVALID_AGE, result);
    }

    @Test
    public void validateRegistryResultDuplicate() {
        Person person01 = new Person("DIEGO",2159096,20,Gender.MALE,true);
        Person person02 = new Person("NIKOLAS",2159096,19,Gender.MALE,true);

        RegisterResult result01 = registry.registerVoter(person01);
        RegisterResult result02 = registry.registerVoter(person02);

        Assert.assertEquals(RegisterResult.VALID, result01);
        Assert.assertEquals(RegisterResult.DUPLICATED, result02);
    }

    @Test
    public void validateRegistryResultValid() {
        Person person = new Person("NIKOLAS",2159096,19,Gender.MALE,true);

        RegisterResult result = registry.registerVoter(person);

        Assert.assertEquals(RegisterResult.VALID, result);
    }
}
