package edu.eci.cvds.tdd.aerodescuentos;

import org.junit.Assert;
import org.junit.Test;

public class TarifasTest{
    /*@Test
    public void validateDiasAntelacin(){
        Person person = new Person();

        RegisterResult result = registry.registerVoter(person);

        Assert.assertEquals(RegisterResult.DEAD, result);
    }*/

    @Test
    public void validateDiasAntelacionErroneo(){
        double tarifaBase = 50000; 
        int diasAntelacion = -2; 
        int edad = 20;

        double tarifa = CalculadorDescuentos.calculoTarifa(tarifaBase, diasAntelacion, edad);

        Assert.assertEquals("ExcepcionParametrosInvalidos",tarifa);
    }

    @Test
    public void validateDiasAntelacionCorrecto01(){
        double tarifaBase = 50000; 
        int diasAntelacion = 0; 
        int edad = 20;
        double ans = 50000.0;

        double tarifa = CalculadorDescuentos.calculoTarifa(tarifaBase, diasAntelacion, edad);

        Assert.assertTrue(tarifa==ans);
    }

    @Test
    public void validateDiasAntelacionCorrecto02(){
        double tarifaBase = 50000; 
        int diasAntelacion = 35; 
        int edad = 80;
        double ans = 38500.0;

        double tarifa = CalculadorDescuentos.calculoTarifa(tarifaBase, diasAntelacion, edad);

        Assert.assertTrue(tarifa==ans);
    }

    @Test
    public void validateEdadErronea01(){
        double tarifaBase = 50000; 
        int diasAntelacion = 0; 
        int edad = -10;

        double tarifa = CalculadorDescuentos.calculoTarifa(tarifaBase, diasAntelacion, edad);

        Assert.assertEquals("ExcepcionParametrosInvalidos",tarifa);
    }

    @Test
    public void validateEdadErronea02(){
        double tarifaBase = 50000; 
        int diasAntelacion = 0; 
        int edad = 1000;

        double tarifa = CalculadorDescuentos.calculoTarifa(tarifaBase, diasAntelacion, edad);

        Assert.assertEquals("ExcepcionParametrosInvalidos",tarifa);
    }

    @Test
    public void validateEdadCorrecta(){
        double tarifaBase = 50000; 
        int diasAntelacion = 21; 
        int edad = 50;
        double ans = 42500.0;

        double tarifa = CalculadorDescuentos.calculoTarifa(tarifaBase, diasAntelacion, edad);

        Assert.assertTrue(ans==tarifa);
    }
}
