# DATOS PERSONALES - CVDS
```python
print("Hello GitHub")
```

Estudiante de *Ingenieria de Sistemas* en la [*Escuela Colombiana de Ingenieria Julio Garavito*](https://www.escuelaing.edu.co/es/).

**Nombre:** Diego Alejandro Murcia Céspedes\
**Direccion:** cll 173a # 20a - 32, int 9 - apto 333\
**Telefono:** 3164590533 - 7510443\
**C.C:** 1004678728\
**RH:** O+

## Redes Sociales
* [![alt text][1.1]][1] 
* [![alt text][2.1]][2] 
* [![alt text][3.1]][3]

## Top 3 - Comidas Favoritas
1. Sushi\
![alt text][4.1]
2. Pasta\
![alt text][5.1]
3. Carne\
![alt text][6.1]

[1]: https://twitter.com/__DiegoMurcia
[2]: https://www.facebook.com/diego.murcia.775
[3]: https://github.com/DiegoMurcia2022


[1.1]: http://i.imgur.com/tXSoThF.png
[2.1]: http://i.imgur.com/P3YfQoD.png
[3.1]: http://i.imgur.com/0o48UoR.png
[4.1]: http://www.clker.com/cliparts/E/p/0/y/8/T/sushi-hi.png
[5.1]: http://lacantinaitalianrestaurant.com/wp-content/uploads/2016/07/ped-pasta-1.png
[6.1]: https://cdn11.bigcommerce.com/s-7tefearjt6/products/192/images/471/Tomahawk_Steak__76968.1554476598.386.513.png?c=2