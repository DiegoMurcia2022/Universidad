# Datos Basicos: 

**Nombre:** Nikolás Bernal Girlado\
**Carrera:** Ingeniería de Sistemas\
**Semestre:** 8vo\
**Ciudad:** *Bogotá* \
**Deportes:**
1. Voleyball
2. Futbol
3. Basket

## Redes Sociales:
* Facebook
* Instagram

### ***Imagen de un gato***

![Gato](https://estaticos.muyinteresante.es/media/cache/1140x_thumb/uploads/images/gallery/59c4f5655bafe82c692a7052/gato-marron_0.jpg)

[Escuela colombiana de Ingenieria](https://www.escuelaing.edu.co/es/comunidad/estudiantes)

#### **Codigo para git**

```
git add .
git commit -m "NOMBRE DEL COMMIT"
git push URL_REPOSITORIO master
```


