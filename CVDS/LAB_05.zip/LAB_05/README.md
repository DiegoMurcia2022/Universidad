# LABORATORIO No.05

Los integrantes de este laboratorio son:

* Nikolas Bernal Giraldo
* Diego Alejandro Murcia Cespedes

## PARTE III
### Punto 20
Al usar el metodo ```POST``` tenermos el siguiente resultado:
![](images/HTML_POST.png)

Luego, al usar el metodo ```GET``` tenermos el siguiente resultado:
![](images/HTML_GET.png)

La diferencia se hace evidente si observamos la URL de la pagina web, donde al usar 
el metodoto ```GET``` se nos muestra los parametros ingresados para el
```id```, en cambio con el metodo ```POST``` no pasa esto.

### Punto 21
La clase ```Service.java``` realiza una conexion entre la [URL](https://jsonplaceholder.typicode.com/todos/) dada y
el objeto ```URLConnection```. La información es de tipo HTML para que el navegador la reconozca, y para esto
se utilizan los metodos presentados en la clase.

## PARTE IV
### Diagrama de Clases del Proyecto
![](images/Diagrama_Clases.png)

### Pruebas de Aceptacion
 ![](images/Calculator_Test.png)
 
 ![](images/Calculator_Test_Private.png)
 
 ![](images/Inspector_WebApp.png)
 
 ![](images/Inspector_WebApp_Style.png)
 
 ![](images/Inspector_WebApp_Style_Change.png)
 
