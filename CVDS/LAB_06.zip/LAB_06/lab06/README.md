# Laboratorio No.06
[![CircleCI](https://circleci.com/gh/PDSW-ECI/base-proyectos.svg?style=svg)](https://app.circleci.com/pipelines/github/DiegoMurcia2022/CVDS-02_LAB-06_2020)
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/bcfdcc8049e84a9790284fba605ef51a)](https://app.codacy.com/manual/DiegoMurcia2022/CVDS-02_LAB-06_2020?utm_source=github.com&utm_medium=referral&utm_content=DiegoMurcia2022/CVDS-02_LAB-06_2020&utm_campaign=Badge_Grade_Dashboard)

Los integrantes de este laboratorio son:
* Nikolas Bernal Giraldo
* Diego Alejandro Murcia Cespedes

El despliegue de la aplicacion se puede encontrar en [Heroku](https://web-app-lab06.herokuapp.com/guess.xhtml).