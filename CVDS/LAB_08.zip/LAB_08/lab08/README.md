# Laboratorio No.08
[![CircleCI](https://circleci.com/gh/PDSW-ECI/base-proyectos.svg?style=svg)](https://app.circleci.com/pipelines/github/DiegoMurcia2022/CVDS-02_LAB-08_2020)
[![Codacy Badge](https://app.codacy.com/project/badge/Grade/c13e30ae71bd4c74a08c26657e1083aa)](https://www.codacy.com/gh/DiegoMurcia2022/CVDS-02_LAB-08_2020-2/dashboard?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=DiegoMurcia2022/CVDS-02_LAB-08_2020-2&amp;utm_campaign=Badge_Grade)

Los integrantes de este laboratorio son:
   * Nikolas Bernal Giraldo
   * Diego Alejandro Murcia Céspedes