# Laboratorio No.06
Los integrantes de este laboratorio son:
   * Nikolas Bernal Giraldo
   * Diego Alejandro Murcia Céspedes