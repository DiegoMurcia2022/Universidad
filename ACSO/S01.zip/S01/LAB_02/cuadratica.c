#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <math.h>

bool validate(double a,double b,double c){
    double op;

    op = (b*b)-(4*a*c);

    if(op>=0){
        return true;
    }

    return false;
}

void raiz(double a,double b,double c){
    double value,op01,op02;

    value = sqrt((b*b)-(4*a*c));

    op01 = (-b+value)/(2*a);
    op02 = (-b-value)/(2*a);
    
    if(op01==op02){
        printf("%.2lf\n",op01);
    }
    else{
        printf("%.2lf\n",op01);
        printf("%.2lf\n",op02);
    }
}

int main(){
    bool valid;
    double cases,a,b,c,i;

    scanf("%lf",&cases);

    for(i=0;i<cases;i++){
        scanf("%lf",&a);
        scanf("%lf",&b);
        scanf("%lf",&c);

        valid = validate(a,b,c);

        if(valid){
            raiz(a,b,c);
        }
        else{
            printf("no roots\n");
        }
    }

    return 0;
}