#include <stdio.h>

int main(void){
    int val01,val02,rta;

    printf("Ingre un numero: ");
    scanf("%d",&val01);

    printf("Ingrese otro numero: ");
    scanf("%d",&val02);

    rta = val01+val02;

    printf("La suma de los dos valores es: %d\n ",rta);

    return 0;
}
