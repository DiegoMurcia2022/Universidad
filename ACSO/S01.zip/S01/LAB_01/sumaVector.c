#include <stdio.h>

int* leerVector(int *vector,int size){
    int i;

    for(i=0;i<size;i++){
        printf("Ingrese el numero: ");
        scanf("%d",&vector[i]);
    }

    return vector;
}

int suma(int *vector,int size){
    int i,rta = 0;

    for(i=0;i<size;i++){
        rta += vector[i];
    }

    return rta;
}

int main(){
    int val;

    printf("Ingrese la cantidad de numeros que desea va a ingresar: ");
    scanf("%d",&val);

    int vector[val];

    int *array = leerVector(vector,val);

    printf("La suma de todos los elementos contenidos en el vector es %d\n",suma(array,val));

    return 0;
}