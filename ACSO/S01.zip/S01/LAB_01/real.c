#include <stdio.h>

int main(void){
    float a,b;

    printf("Ingrese un numero: ");
    scanf("%f",&a);

    printf("Ingrese otro numero: ");
    scanf("%f",&b);

    if(a>b){
        printf("%f es el mayor de los numeros ingresados.\n",a);
    }
    else if(a<b){
        printf("%f es el mayor de los numeros ingresados.\n",b);
    }
    else{
        printf("Ambos numeros ingresados son iguales.\n");
    }

    return 0;
}