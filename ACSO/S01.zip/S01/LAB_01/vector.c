#include <stdio.h>

int main(void){
    int n,i,j;
    float val;

    printf("Ingrese la cantidad de numeros que va ingresar: ");
    scanf("%d",&n);

    float vector[n];

    for(i=0;i<n;i++){
        printf("Ingrese numero: ");
        scanf("%f",&vector[i]);
    }

    float rta = 0;

    for(j=0;j<n;j++){
        if(vector[j]>rta){
            rta = vector[j];
        }
    }

    printf("El numero %f es el mayor en el vector.\n",rta);

    return 0;
}