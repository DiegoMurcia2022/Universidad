#include <stdio.h>

void menu(){
    printf("----------MENU CALCULADORA----------\n");
    printf("             1. Sumar               \n");
    printf("             2. Restar              \n");
    printf("             3. Multiplicar         \n");
    printf("             4. Dividir             \n");
    printf("             5. Salir               \n");
    printf("\n");
}

float suma(){
    int val,i,j;
    float rta;

    printf("\n");
    printf("Ingrese la cantidad de numeros que desea sumar: ");
    scanf("%d",&val);

    float array[val];

    printf("\n");

    for(i=0;i<val;i++){
        printf("Ingrese un numero: ");
        scanf("%f",&array[i]);
    }

    rta = 0;

    for(j=0;j<val;j++){
        rta += array[j];
    }

    printf("\n");

    return rta;
}

float resta(){
    float num01,num02,rta;

    printf("\n");
    printf("Ingrese el primer numero: ");
    scanf("%f",&num01);
    printf("Ingrese el segundo numero: ");
    scanf("%f",&num02);

    printf("\n");

    rta = num01-num02;

    return rta;
}

float multiplicacion(){
    float num01,num02,rta;

    printf("\n");
    printf("Ingrese el primer numero: ");
    scanf("%f",&num01);
    printf("Ingrese el segundo numero: ");
    scanf("%f",&num02);

    printf("\n");

    rta = num01*num02;

    return rta;
}

float division(){
    float num01,num02,rta;

    printf("\n");
    printf("Ingrese el primer numero: ");
    scanf("%f",&num01);
    printf("Ingrese el segundo numero: ");
    scanf("%f",&num02);

    printf("\n");

    rta = num01/num02;

    return rta;
}

int main(){
    int option;
    float rta;

    printf("\n");

    menu();

    printf("Ingrese el numero de alguna de las opciones: ");
    scanf("%d",&option);

    while(option!=5){
        if(option==1){
            rta = suma();

            printf("El total de la suma es %f\n",rta);
        }
        else if(option==2){
            rta = resta();

            printf("El total de la resta es %f\n",rta);
        }
        else if(option==3){
            rta = multiplicacion();

            printf("El total de la multiplicacion es %f\n",rta);
        }
        else if(option==4){
            rta = division();

            printf("El total de la multiplicacion es %f\n",rta);
        }
        
        printf("\n");

        menu();

        printf("Ingrese el numero de alguna de las opciones: ");
        scanf("%d",&option);
    }

    printf("\n");

    return 0;
}