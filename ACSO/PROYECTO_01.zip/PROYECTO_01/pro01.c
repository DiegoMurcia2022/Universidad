#include <stdlib.h>
#include <stdio.h>

void egipcio(unsigned long int a,unsigned long int b){
    unsigned long int value,numerador,denominador,val01,val02;

    if(a==0 || b==0){
        return;
    }

    if(b%a==0){
        printf("%lu\n",b/a);

        return;
    }

    if(a%b==0){
        printf("%lu\n",a/b);

        return;
    }

    if(a>b){
        egipcio(a%b,b);
    }

    value = (b/a)+1;

    numerador = (a*value)-b;
    denominador = b*value;

    printf("%lu\n",value);

    return egipcio(numerador,denominador);
}

int main(){
    unsigned long int cases,numerador,denominador,i;

    scanf("%lu",&cases);

    for(i=0;i<cases;i++){
        scanf("%lu",&numerador);
        scanf("%lu",&denominador);

        if(numerador==1){
            printf("%lu\n",denominador);
        }
        else{
            egipcio(numerador,denominador);
        }   

        printf("0\n");
    }

    return 0;
}